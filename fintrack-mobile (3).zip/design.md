# FinTrack - Financial Market Predictor
## Mobile App Interface Design Plan

### Design Philosophy
This app follows **Apple Human Interface Guidelines (HIG)** to feel like a first-party iOS app. The design assumes **mobile portrait orientation (9:16)** and **one-handed usage**.

---

## Screen List

1. **Market Overview** (Home Tab)
2. **Asset Detail** (Drill-down screen)
3. **Indicators** (Second Tab)
4. **Watchlist** (Third Tab)
5. **Settings** (Fourth Tab)

---

## Screen Details

### 1. Market Overview (Home Tab)
**Primary Content:**
- Live price cards for major categories:
  - Forex pairs (EUR/USD, GBP/USD, USD/JPY, etc.)
  - Commodities (XAUUSD - Gold, XAGUSD - Silver, Oil, etc.)
  - Cryptocurrencies (Bitcoin, Ethereum, etc.)
- Each card shows:
  - Asset name and symbol
  - Current price
  - 24h change (percentage and absolute value)
  - Mini sparkline chart (last 24h)
  - Trend indicator (up/down arrow with color)

**Functionality:**
- Pull-to-refresh to update prices
- Tap any card to navigate to Asset Detail screen
- Search bar at top to filter assets
- Category filter chips (All, Forex, Commodities, Crypto)

**Layout:**
- Scrollable vertical list of cards
- Cards have rounded corners, subtle shadows
- Green for positive changes, red for negative
- Compact spacing for one-handed scrolling

---

### 2. Asset Detail (Drill-down)
**Primary Content:**
- Large price display at top
- Interactive price chart with timeframe selector (1H, 4H, 1D, 1W, 1M)
- Technical indicators summary section showing:
  - Top 5 most relevant indicators for this asset
  - Signal strength (Strong Buy, Buy, Neutral, Sell, Strong Sell)
  - Visual indicator bars or gauges
- "View All Indicators" button to see full list
- Price prediction section:
  - Short-term prediction (next 1-4 hours)
  - Medium-term prediction (next 24 hours)
  - Confidence level percentage

**Functionality:**
- Pinch-to-zoom on chart
- Swipe between timeframes
- Add/remove from watchlist (heart icon in header)
- Share button to export chart/analysis
- Real-time price updates (WebSocket or polling)

**Layout:**
- Sticky header with back button and watchlist toggle
- Chart takes up 40% of screen height
- Indicators section in collapsible cards
- Bottom sheet for detailed indicator breakdown

---

### 3. Indicators (Second Tab)
**Primary Content:**
- Complete list of 30+ technical indicators organized by category:
  - **Trend Indicators**: Moving Averages (SMA, EMA, WMA), MACD, ADX, Parabolic SAR, Ichimoku Cloud
  - **Momentum Indicators**: RSI, Stochastic Oscillator, CCI, Williams %R, ROC, MFI
  - **Volatility Indicators**: Bollinger Bands, ATR, Keltner Channels, Standard Deviation
  - **Volume Indicators**: OBV, Volume Weighted Average Price (VWAP), Accumulation/Distribution, Chaikin Money Flow
  - **Support/Resistance**: Pivot Points, Fibonacci Retracement, Donchian Channels
  - **Custom Composite**: Aggregate signal combining multiple indicators

**Functionality:**
- Each indicator shows:
  - Name and brief description
  - Current signal (Buy/Sell/Neutral)
  - Strength meter
  - Last updated timestamp
- Tap indicator to see detailed explanation and formula
- Toggle indicators on/off for personalized analysis
- Filter by signal type (Show only Buy signals, etc.)

**Layout:**
- Segmented control at top for category selection
- List of indicator cards with consistent styling
- Color-coded signals (green/red/gray)
- Expandable cards for detailed view

---

### 4. Watchlist (Third Tab)
**Primary Content:**
- User's saved assets for quick access
- Same card format as Market Overview
- Drag-to-reorder functionality
- Empty state with "Add assets to track" message

**Functionality:**
- Swipe-to-delete assets from watchlist
- Tap to navigate to Asset Detail
- Pull-to-refresh for price updates
- Quick add button (floating action button)

**Layout:**
- Clean list view with reorder handles
- Floating "+" button at bottom-right
- Empty state illustration when no assets saved

---

### 5. Settings (Fourth Tab)
**Primary Content:**
- App preferences:
  - Currency display (USD, EUR, GBP, etc.)
  - Price update frequency (Real-time, 1min, 5min)
  - Notification preferences (Price alerts, Signal alerts)
  - Theme (Light, Dark, Auto)
- About section:
  - App version
  - Data sources attribution
  - Terms & Privacy links

**Functionality:**
- Toggle switches for notifications
- Picker for currency and update frequency
- Links open in-app browser or external browser

**Layout:**
- Grouped list style (iOS Settings app pattern)
- Section headers for organization
- Standard iOS form controls

---

## Key User Flows

### Flow 1: Check Bitcoin Price and Indicators
1. User opens app → Lands on Market Overview
2. User scrolls to Crypto section
3. User taps Bitcoin card
4. Asset Detail screen opens with live chart
5. User scrolls down to see indicator signals
6. User taps "View All Indicators" button
7. Bottom sheet slides up showing all 30+ indicators
8. User reviews signals and makes trading decision

### Flow 2: Add Asset to Watchlist
1. User navigates to Asset Detail screen
2. User taps heart icon in header
3. Icon fills with color (animation)
4. Toast notification: "Added to Watchlist"
5. User switches to Watchlist tab
6. Asset now appears in watchlist

### Flow 3: View Specific Indicator Details
1. User taps Indicators tab
2. User selects "Momentum" category
3. User scrolls to "RSI" indicator
4. User taps RSI card
5. Modal/sheet opens with:
   - Full explanation of RSI
   - Current value and signal
   - Historical chart of RSI values
   - Recommended actions based on RSI level

### Flow 4: Receive Price Alert
1. User sets price alert in Asset Detail (future feature)
2. Price crosses threshold
3. Push notification sent
4. User taps notification
5. App opens directly to that Asset Detail screen

---

## Color Choices

**Brand Colors:**
- **Primary**: `#0A7EA4` (Teal Blue) - Professional, trustworthy, financial
- **Success/Bullish**: `#22C55E` (Green) - Positive price movements
- **Error/Bearish**: `#EF4444` (Red) - Negative price movements
- **Warning**: `#F59E0B` (Amber) - Neutral/caution signals
- **Background Light**: `#FFFFFF` (White)
- **Background Dark**: `#151718` (Near Black)
- **Surface Light**: `#F5F5F5` (Light Gray)
- **Surface Dark**: `#1E2022` (Dark Gray)
- **Text Primary**: `#11181C` (Dark) / `#ECEDEE` (Light in dark mode)
- **Text Muted**: `#687076` (Gray) / `#9BA1A6` (Light Gray in dark mode)

**Usage:**
- Charts use green/red for candlesticks and trend lines
- Indicator signals use traffic light system (green/amber/red)
- Cards have subtle elevation with surface color
- Primary color used for interactive elements (buttons, links, active states)

---

## Technical Considerations

- **Data Source**: Will use free financial APIs (Twelve Data, Alpha Vantage, or CoinGecko for crypto)
- **Update Frequency**: Poll every 60 seconds for price updates (configurable)
- **Indicators**: Implement calculation engine locally using historical price data
- **Storage**: AsyncStorage for watchlist and user preferences (local-first, no auth required)
- **Charts**: Use react-native-svg with custom charting or lightweight library
- **Performance**: Memoize indicator calculations, lazy load historical data

---

## Design Patterns

- **Navigation**: Bottom tab bar (4 tabs max for thumb reach)
- **Cards**: Rounded corners (12px), subtle shadow, tappable with press feedback
- **Typography**: SF Pro (iOS native), clear hierarchy (32px titles, 16px body, 14px captions)
- **Spacing**: 8px base unit, consistent padding (16px screen edges, 12px card padding)
- **Animations**: Subtle (250ms), spring animations for interactive feedback
- **Loading States**: Skeleton screens for initial load, shimmer effect
- **Error States**: Inline error messages with retry button
- **Empty States**: Friendly illustrations with clear call-to-action

---

## Accessibility

- Minimum touch target size: 44x44 points
- Color is not the only indicator (use icons + text for signals)
- Dynamic type support for text scaling
- VoiceOver labels for all interactive elements
- Sufficient color contrast ratios (WCAG AA)

---

## Future Enhancements (Not in MVP)

- User authentication for cloud sync
- Custom indicator builder
- Price alerts and notifications
- Portfolio tracking
- Social features (share analysis)
- News feed integration
- Advanced charting tools (drawing tools, multiple indicators on chart)
