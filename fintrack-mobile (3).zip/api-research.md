# Financial Data API Research

## Alpha Vantage

**Website:** https://www.alphavantage.co/

### Key Features
- Free API key available
- Supports: Stocks, Forex, Cryptocurrencies, Commodities, Technical Indicators
- 20+ years of historical data
- Multiple timeframes: intraday (1min, 5min, 15min, 30min, 60min), daily, weekly, monthly

### Forex API
- **Function:** `CURRENCY_EXCHANGE_RATE`
- Returns real-time exchange rates for any currency pair
- Example: EUR/USD, GBP/USD, USD/JPY

### Commodities API
Available commodities:
- Crude Oil (WTI)
- Crude Oil (Brent)
- Natural Gas
- Copper
- Aluminum
- Wheat, Corn, Cotton, Sugar, Coffee
- **Note:** Gold (XAUUSD) available through Forex API as XAU/USD pair

### Cryptocurrency API
- **Function:** `CRYPTO_EXCHANGE_RATE`
- Supports Bitcoin, Ethereum, and other cryptocurrencies
- Real-time and historical data

### Technical Indicators API
Alpha Vantage provides built-in technical indicators including:
- SMA (Simple Moving Average)
- EMA (Exponential Moving Average)
- WMA (Weighted Moving Average)
- MACD
- STOCH (Stochastic Oscillator)
- RSI (Relative Strength Index)
- ADX (Average Directional Index)
- CCI (Commodity Channel Index)
- WILLR (Williams %R)
- ROC (Rate of Change)
- And many more (30+ indicators available)

### Rate Limits
- Free tier: 25 API calls per day
- Premium tiers available for higher limits

### API Key
- Free API key: https://www.alphavantage.co/support/#api-key

---

## Twelve Data

**Website:** https://twelvedata.com/

### Key Features
- Free tier: 800 API calls per day
- Real-time data for US markets, forex, and cryptocurrencies
- WebSocket support for real-time streaming
- JSON and CSV formats

### Coverage
- Stocks (US and international)
- Forex pairs
- Cryptocurrencies
- Indices

---

## CoinGecko

**Website:** https://www.coingecko.com/en/api

### Key Features
- Free cryptocurrency API
- No API key required for basic usage
- Tracks 18,990+ cryptocurrencies
- Real-time prices, market cap, volume, charts

### Endpoints
- `/simple/price` - Get current prices by coin ID
- `/coins/{id}/market_chart` - Historical market data
- `/coins/markets` - List of coins with market data

---

## Recommended Approach

For this project, we'll use:

1. **Alpha Vantage** - Primary API for:
   - Forex pairs (EUR/USD, GBP/USD, USD/JPY, etc.)
   - Commodities via Forex (XAU/USD for gold)
   - Technical indicators (built-in calculations)

2. **CoinGecko** - For cryptocurrency data:
   - Bitcoin, Ethereum, and other crypto prices
   - No API key required
   - Higher rate limits for free tier

3. **Local Calculation** - For indicators not available in Alpha Vantage:
   - Implement custom indicator calculations
   - Use historical price data from APIs

### Implementation Strategy
- Cache API responses to minimize calls
- Poll every 60 seconds for price updates
- Store historical data locally for indicator calculations
- Use AsyncStorage for caching and offline support
