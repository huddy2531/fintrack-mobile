/**
 * Enhanced Technical Indicators with Asset Type Tracking
 * Adds clear asset identification to all indicator signals
 */

import { IndicatorSignal, Asset } from './multi-provider-api';

export interface PriceData {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface IndicatorResult {
  value: number;
  signal: 'buy' | 'sell' | 'neutral';
  strength: number; // 0-100
}

// ============================================
// TREND INDICATORS
// ============================================

/**
 * Simple Moving Average (SMA)
 */
export function calculateSMA(data: number[], period: number): number[] {
  const result: number[] = [];
  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) {
      result.push(NaN);
    } else {
      const sum = data.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0);
      result.push(sum / period);
    }
  }
  return result;
}

/**
 * Exponential Moving Average (EMA)
 */
export function calculateEMA(data: number[], period: number): number[] {
  const result: number[] = [];
  const multiplier = 2 / (period + 1);

  // First EMA is SMA
  const firstSMA = data.slice(0, period).reduce((a, b) => a + b, 0) / period;
  result.push(firstSMA);

  for (let i = period; i < data.length; i++) {
    const ema = (data[i] - result[result.length - 1]) * multiplier + result[result.length - 1];
    result.push(ema);
  }

  return result;
}

/**
 * Weighted Moving Average (WMA)
 */
export function calculateWMA(data: number[], period: number): number[] {
  const result: number[] = [];
  const weights = Array.from({ length: period }, (_, i) => i + 1);
  const weightSum = weights.reduce((a, b) => a + b, 0);

  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) {
      result.push(NaN);
    } else {
      const slice = data.slice(i - period + 1, i + 1);
      const weightedSum = slice.reduce((sum, val, idx) => sum + val * weights[idx], 0);
      result.push(weightedSum / weightSum);
    }
  }

  return result;
}

/**
 * MACD (Moving Average Convergence Divergence)
 */
export function calculateMACD(data: number[], fastPeriod = 12, slowPeriod = 26, signalPeriod = 9) {
  const emaFast = calculateEMA(data, fastPeriod);
  const emaSlow = calculateEMA(data, slowPeriod);

  const macdLine = emaFast.map((fast, i) => fast - emaSlow[i]);
  const signalLine = calculateEMA(macdLine.filter(v => !isNaN(v)), signalPeriod);
  const histogram = macdLine.slice(-signalLine.length).map((macd, i) => macd - signalLine[i]);

  return { macdLine, signalLine, histogram };
}

// ============================================
// MOMENTUM INDICATORS
// ============================================

/**
 * RSI (Relative Strength Index)
 */
export function calculateRSI(data: number[], period = 14): IndicatorResult {
  const changes = [];
  for (let i = 1; i < data.length; i++) {
    changes.push(data[i] - data[i - 1]);
  }

  const gains = changes.map(c => (c > 0 ? c : 0));
  const losses = changes.map(c => (c < 0 ? -c : 0));

  const avgGain = gains.slice(-period).reduce((a, b) => a + b, 0) / period;
  const avgLoss = losses.slice(-period).reduce((a, b) => a + b, 0) / period;

  const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
  const rsi = 100 - 100 / (1 + rs);

  let signal: 'buy' | 'sell' | 'neutral' = 'neutral';
  let strength = 0;

  if (rsi < 30) {
    signal = 'buy';
    strength = Math.abs(30 - rsi) / 30 * 100;
  } else if (rsi > 70) {
    signal = 'sell';
    strength = Math.abs(rsi - 70) / 30 * 100;
  } else {
    strength = 50;
  }

  return { value: rsi, signal, strength };
}

/**
 * Stochastic Oscillator
 */
export function calculateStochastic(priceData: PriceData[], period = 14) {
  const closes = priceData.map(p => p.close);
  const lows = priceData.map(p => p.low);
  const highs = priceData.map(p => p.high);

  const kValues: number[] = [];

  for (let i = period - 1; i < closes.length; i++) {
    const periodLow = Math.min(...lows.slice(i - period + 1, i + 1));
    const periodHigh = Math.max(...highs.slice(i - period + 1, i + 1));
    const k = ((closes[i] - periodLow) / (periodHigh - periodLow)) * 100;
    kValues.push(k);
  }

  const lastK = kValues[kValues.length - 1];
  let signal: 'buy' | 'sell' | 'neutral' = 'neutral';
  let strength = 0;

  if (lastK < 20) {
    signal = 'buy';
    strength = Math.abs(20 - lastK) / 20 * 100;
  } else if (lastK > 80) {
    signal = 'sell';
    strength = Math.abs(lastK - 80) / 20 * 100;
  } else {
    strength = 50;
  }

  return { value: lastK, signal, strength };
}

/**
 * MACD Signal
 */
export function calculateMACDSignal(data: number[]): IndicatorResult {
  const macd = calculateMACD(data);
  const lastMACD = macd.macdLine[macd.macdLine.length - 1];
  const lastSignal = macd.signalLine[macd.signalLine.length - 1];
  const lastHistogram = macd.histogram[macd.histogram.length - 1];

  let signal: 'buy' | 'sell' | 'neutral' = 'neutral';
  let strength = 0;

  if (lastHistogram > 0 && lastMACD > lastSignal) {
    signal = 'buy';
    strength = Math.min(100, Math.abs(lastHistogram) * 10);
  } else if (lastHistogram < 0 && lastMACD < lastSignal) {
    signal = 'sell';
    strength = Math.min(100, Math.abs(lastHistogram) * 10);
  } else {
    strength = 50;
  }

  return { value: lastMACD, signal, strength };
}

// ============================================
// VOLATILITY INDICATORS
// ============================================

/**
 * Bollinger Bands
 */
export function calculateBollingerBands(data: number[], period = 20, stdDev = 2) {
  const sma = calculateSMA(data, period);
  const lastSMA = sma[sma.length - 1];

  const variance =
    data
      .slice(-period)
      .reduce((sum, val) => sum + Math.pow(val - lastSMA, 2), 0) / period;
  const std = Math.sqrt(variance);

  const upperBand = lastSMA + stdDev * std;
  const lowerBand = lastSMA - stdDev * std;
  const lastPrice = data[data.length - 1];

  let signal: 'buy' | 'sell' | 'neutral' = 'neutral';
  let strength = 0;

  if (lastPrice < lowerBand) {
    signal = 'buy';
    strength = Math.min(100, Math.abs(lastPrice - lowerBand) / std * 50);
  } else if (lastPrice > upperBand) {
    signal = 'sell';
    strength = Math.min(100, Math.abs(lastPrice - upperBand) / std * 50);
  } else {
    strength = 50;
  }

  return {
    value: lastPrice,
    signal,
    strength,
    upperBand,
    lowerBand,
    middleBand: lastSMA,
  };
}

/**
 * ATR (Average True Range)
 */
export function calculateATR(priceData: PriceData[], period = 14): IndicatorResult {
  const trueRanges: number[] = [];

  for (let i = 1; i < priceData.length; i++) {
    const current = priceData[i];
    const previous = priceData[i - 1];

    const tr1 = current.high - current.low;
    const tr2 = Math.abs(current.high - previous.close);
    const tr3 = Math.abs(current.low - previous.close);

    const tr = Math.max(tr1, tr2, tr3);
    trueRanges.push(tr);
  }

  const atr = trueRanges.slice(-period).reduce((a, b) => a + b, 0) / period;
  const lastPrice = priceData[priceData.length - 1].close;
  const atrPercent = (atr / lastPrice) * 100;

  let signal: 'buy' | 'sell' | 'neutral' = 'neutral';
  let strength = 50;

  if (atrPercent > 2) {
    signal = 'sell'; // High volatility
    strength = Math.min(100, atrPercent * 20);
  } else if (atrPercent < 0.5) {
    signal = 'buy'; // Low volatility, potential breakout
    strength = Math.min(100, (1 - atrPercent) * 100);
  }

  return { value: atr, signal, strength };
}

// ============================================
// ENHANCED SIGNAL GENERATION WITH ASSET INFO
// ============================================

/**
 * Generate indicator signal with asset context
 */
export function generateIndicatorSignal(
  asset: Asset,
  indicatorName: string,
  result: IndicatorResult
): IndicatorSignal {
  return {
    assetId: asset.id,
    assetSymbol: asset.symbol,
    assetType: asset.type,
    assetName: asset.name,
    indicatorName,
    signal: result.signal,
    strength: result.strength,
    value: result.value,
    timestamp: Date.now(),
    provider: asset.provider,
  };
}

/**
 * Calculate all indicators for an asset
 */
export function calculateAllIndicators(
  asset: Asset,
  priceData: PriceData[]
): IndicatorSignal[] {
  const signals: IndicatorSignal[] = [];
  const closes = priceData.map(p => p.close);

  try {
    // RSI
    const rsiResult = calculateRSI(closes);
    signals.push(generateIndicatorSignal(asset, 'RSI (14)', rsiResult));

    // MACD
    const macdResult = calculateMACDSignal(closes);
    signals.push(generateIndicatorSignal(asset, 'MACD', macdResult));

    // Stochastic
    const stochResult = calculateStochastic(priceData);
    signals.push(generateIndicatorSignal(asset, 'Stochastic', stochResult));

    // Bollinger Bands
    const bbResult = calculateBollingerBands(closes);
    signals.push(generateIndicatorSignal(asset, 'Bollinger Bands', bbResult));

    // ATR
    const atrResult = calculateATR(priceData);
    signals.push(generateIndicatorSignal(asset, 'ATR', atrResult));

    // Moving Averages
    const sma20 = calculateSMA(closes, 20);
    const sma50 = calculateSMA(closes, 50);
    const lastPrice = closes[closes.length - 1];

    let maSignal: 'buy' | 'sell' | 'neutral' = 'neutral';
    if (sma20[sma20.length - 1] > sma50[sma50.length - 1] && lastPrice > sma20[sma20.length - 1]) {
      maSignal = 'buy';
    } else if (sma20[sma20.length - 1] < sma50[sma50.length - 1] && lastPrice < sma20[sma20.length - 1]) {
      maSignal = 'sell';
    }

    signals.push(
      generateIndicatorSignal(asset, 'SMA (20/50)', {
        value: sma20[sma20.length - 1],
        signal: maSignal,
        strength: 70,
      })
    );
  } catch (error) {
    console.error(`Error calculating indicators for ${asset.symbol}:`, error);
  }

  return signals;
}

/**
 * Get signal color based on type and strength
 */
export function getSignalColor(signal: 'buy' | 'sell' | 'neutral', strength: number): string {
  if (signal === 'buy') {
    return strength > 75 ? '#10b981' : strength > 50 ? '#6ee7b7' : '#a7f3d0'; // Green shades
  } else if (signal === 'sell') {
    return strength > 75 ? '#ef4444' : strength > 50 ? '#f87171' : '#fca5a5'; // Red shades
  } else {
    return strength > 60 ? '#f59e0b' : '#fbbf24'; // Amber shades
  }
}

/**
 * Get signal emoji/icon
 */
export function getSignalIcon(signal: 'buy' | 'sell' | 'neutral'): string {
  switch (signal) {
    case 'buy':
      return '📈';
    case 'sell':
      return '📉';
    case 'neutral':
      return '➡️';
  }
}

/**
 * Format signal strength as text
 */
export function formatSignalStrength(strength: number): string {
  if (strength > 75) return 'Very Strong';
  if (strength > 60) return 'Strong';
  if (strength > 40) return 'Moderate';
  return 'Weak';
}
