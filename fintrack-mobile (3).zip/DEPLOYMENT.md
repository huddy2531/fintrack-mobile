# FinTrack Mobile - Deployment & Configuration Guide

## Pre-Deployment Checklist

### Environment Setup
- [x] Multi-provider API integration configured
- [x] Asset type labels implemented
- [x] Mobile responsiveness verified
- [x] Technical indicators with asset context
- [x] Fallback mechanism implemented
- [x] Error handling configured
- [x] Caching strategy implemented

### API Keys Configuration
- [x] Alpha Vantage API Key
- [x] Twelve Data API Key
- [x] Exchange Rate API Key
- [x] Metal Price API Key
- [x] CoinGecko API (optional)

## Environment Variables

Create a `.env` file in the project root with the following variables:

```env
# API Keys
ALPHA_VANTAGE_KEY=JFRTNC9PNLO09ZE7
TWELVE_DATA_KEY=1920bdc114dc42b39c28a0d7bbd11db6
EXCHANGE_RATE_KEY=e47e8d1dfc2496cab101a168
METAL_PRICE_API_KEY=6f7c54fd367fab3551311b8b3dd9d330

# Optional
COINGECKO_API_KEY=

# App Configuration
EXPO_PUBLIC_APP_NAME=FinTrack Mobile
EXPO_PUBLIC_APP_DESCRIPTION=Real-time financial data with technical indicators
```

## Installation & Setup

### 1. Install Dependencies

```bash
cd /home/ubuntu/fintrack-mobile
pnpm install
```

### 2. Configure Environment

```bash
# Copy environment template
cp .env.example .env

# Update with your API keys
nano .env
```

### 3. Database Setup (if using web-db-user)

```bash
# Push database schema
pnpm db:push
```

### 4. Build for Production

```bash
# Build the application
pnpm build

# Start production server
pnpm start
```

## Deployment Options

### Option 1: Manus Hosting (Recommended)

The application is already configured for Manus hosting with:
- Built-in database support
- Automatic SSL/TLS
- Custom domain support
- Public link sharing

**Steps:**
1. Create checkpoint: `webdev_save_checkpoint`
2. Click "Publish" in Management UI
3. Configure custom domain (optional)
4. Share public link

### Option 2: Docker Deployment

Create a `Dockerfile`:

```dockerfile
FROM node:20-alpine

WORKDIR /app

# Copy package files
COPY package.json pnpm-lock.yaml ./

# Install dependencies
RUN npm install -g pnpm && pnpm install --frozen-lockfile

# Copy source code
COPY . .

# Build application
RUN pnpm build

# Expose port
EXPOSE 3000

# Start application
CMD ["pnpm", "start"]
```

Build and run:

```bash
docker build -t fintrack-mobile .
docker run -p 3000:3000 \
  -e ALPHA_VANTAGE_KEY=your_key \
  -e TWELVE_DATA_KEY=your_key \
  -e EXCHANGE_RATE_KEY=your_key \
  -e METAL_PRICE_API_KEY=your_key \
  fintrack-mobile
```

### Option 3: Vercel/Netlify Deployment

**Note**: This is a React Native + Express app. Vercel/Netlify are better suited for static sites.

For serverless deployment:
1. Deploy Express server to Vercel Functions
2. Deploy React frontend to Vercel/Netlify
3. Configure CORS for cross-origin requests

### Option 4: Self-Hosted (VPS/Server)

```bash
# SSH into your server
ssh user@your-server.com

# Clone repository
git clone <your-repo-url>
cd fintrack-mobile

# Install Node.js and pnpm
curl -fsSL https://get.pnpm.io/install.sh | sh -

# Install dependencies
pnpm install

# Create environment file
nano .env

# Build application
pnpm build

# Use PM2 for process management
npm install -g pm2
pm2 start "pnpm start" --name "fintrack-mobile"
pm2 save
pm2 startup

# Configure Nginx reverse proxy
# (See nginx configuration below)
```

## Nginx Configuration (for Self-Hosted)

Create `/etc/nginx/sites-available/fintrack-mobile`:

```nginx
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;

    # Redirect HTTP to HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name your-domain.com www.your-domain.com;

    # SSL Configuration
    ssl_certificate /etc/letsencrypt/live/your-domain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/your-domain.com/privkey.pem;

    # Security Headers
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;

    # Proxy to Node.js application
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Cache static assets
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

Enable the site:

```bash
sudo ln -s /etc/nginx/sites-available/fintrack-mobile /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

## SSL Certificate (Let's Encrypt)

```bash
sudo apt-get install certbot python3-certbot-nginx
sudo certbot certonly --nginx -d your-domain.com -d www.your-domain.com
```

## Monitoring & Logging

### PM2 Monitoring

```bash
# View logs
pm2 logs fintrack-mobile

# Monitor resources
pm2 monit

# View application status
pm2 status
```

### Application Logging

The application logs to:
- Console (development)
- File system (production)

Configure logging in `server/_core/index.ts`:

```typescript
// Add logging middleware
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
  next();
});
```

## Performance Optimization

### 1. Enable Caching

```typescript
// Redis caching (optional)
import redis from 'redis';

const redisClient = redis.createClient();
```

### 2. Implement Rate Limiting

```typescript
import rateLimit from 'express-rate-limit';

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100 // limit each IP to 100 requests per windowMs
});

app.use('/api/', limiter);
```

### 3. Compress Responses

```typescript
import compression from 'compression';

app.use(compression());
```

### 4. Database Connection Pooling

Configure MySQL connection pool in `server/db.ts`:

```typescript
const pool = mysql.createPool({
  connectionLimit: 10,
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
});
```

## Backup & Recovery

### Database Backup

```bash
# Backup MySQL database
mysqldump -u user -p database_name > backup.sql

# Restore from backup
mysql -u user -p database_name < backup.sql
```

### Application Backup

```bash
# Backup entire application
tar -czf fintrack-mobile-backup.tar.gz /home/ubuntu/fintrack-mobile/

# Restore from backup
tar -xzf fintrack-mobile-backup.tar.gz
```

## Monitoring & Alerts

### Health Check Endpoint

Add to `server/_core/index.ts`:

```typescript
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
  });
});
```

### Monitor with Uptime Robot

1. Create account at https://uptimerobot.com
2. Add monitor for `https://your-domain.com/health`
3. Configure alerts for downtime

## Troubleshooting Deployment

### Port Already in Use

```bash
# Find process using port 3000
lsof -i :3000

# Kill process
kill -9 <PID>
```

### Database Connection Issues

```bash
# Test MySQL connection
mysql -h localhost -u user -p -e "SELECT 1;"

# Check environment variables
env | grep DB_
```

### High Memory Usage

```bash
# Check Node.js memory
node --max-old-space-size=4096 dist/index.js

# Monitor with PM2
pm2 monit
```

### API Rate Limiting

If experiencing rate limits:
1. Check provider health status
2. Reduce polling frequency
3. Implement request batching
4. Use cached data when available

## Rollback Procedure

If deployment fails:

```bash
# Restore from checkpoint
webdev_rollback_checkpoint <version_id>

# Or manually restore
git revert <commit-hash>
git push origin main

# Restart application
pm2 restart fintrack-mobile
```

## Post-Deployment

### Verification Checklist

- [ ] Application accessible at domain
- [ ] SSL certificate valid
- [ ] API endpoints responding
- [ ] Database connected
- [ ] Caching working
- [ ] Fallback mechanism functioning
- [ ] Asset type labels displaying
- [ ] Mobile responsiveness verified
- [ ] Error handling working
- [ ] Logs being generated

### Performance Testing

```bash
# Load testing with Apache Bench
ab -n 1000 -c 10 https://your-domain.com/

# Or use wrk
wrk -t4 -c100 -d30s https://your-domain.com/
```

## Support & Maintenance

### Regular Maintenance

- Update dependencies monthly
- Monitor API provider status
- Review error logs weekly
- Backup database daily
- Check SSL certificate expiration

### Update Dependencies

```bash
# Check for updates
pnpm outdated

# Update packages
pnpm update

# Update major versions
pnpm upgrade
```

## Scaling Considerations

### Horizontal Scaling

For multiple instances:
1. Use load balancer (nginx, HAProxy)
2. Share database across instances
3. Implement session management
4. Use Redis for caching

### Vertical Scaling

For single instance:
1. Increase server resources (CPU, RAM)
2. Optimize database queries
3. Implement caching
4. Compress responses

## Security Considerations

- [ ] Enable HTTPS/SSL
- [ ] Set secure headers
- [ ] Implement rate limiting
- [ ] Validate user input
- [ ] Sanitize database queries
- [ ] Rotate API keys regularly
- [ ] Monitor for suspicious activity
- [ ] Keep dependencies updated
